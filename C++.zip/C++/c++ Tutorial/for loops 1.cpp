#include <iostream>

int main(){

 for(int i = 10; i >= 0 ; i-=2){
  std::cout << i << std::endl ;
 }
std::cout << "Happy new year\n";
    return 0;
}