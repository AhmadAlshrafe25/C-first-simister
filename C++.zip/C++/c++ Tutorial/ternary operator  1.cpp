#include <iostream>

int main(){
//replacement to and if/else statment
// condition ? exprition 1 : expertion2 ;

//int grade = 55 ;
//grade >= 60? std::cout << "You pass" : std::cout << "You fail";

//int num = 1;
//num % 2 == 0? std::cout<<"it's even " : std::cout<<"It's odd";

bool hungry = true ;
hungry == true ? std::cout <<"go eat" : std::cout<< "You are full";


    return 0 ;
}