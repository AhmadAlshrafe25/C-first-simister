#include <iostream>

int main(){
//arithmetic opertators = return the result of spacific
//                        arithmetic operation (+ - * /)

int students = 20;

//students = students + 1 ;
//students+=1;
//students++;

//students = students - 1 ;
//students-=1;
//students-- ;

//students = students * 2;
//students*=2 ;

//students = students / 2;
//students /= 2 ;

int rem = students % 3;

std::cout << students << '\n';
std::cout << rem << '\n';

    return 0 ;
}