#include <iostream>

int main(){
// do a block of code then repeat if true

int num;

do{
    std::cout << "Zaid";
    
}
while(num < 0);

std::cout << "the # num " << num ;

    return 0 ;
}