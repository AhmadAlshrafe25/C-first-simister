#include <iostream>/*i:input o:output*/ 
//iostream is a head file that contains functions for basic input and output operations

int main(){

// this is a comment

    std::cout <<"I like Falafel" << '\n'/*new line character*/;// makes the compiler that this statement is done
    std::cout <<"It's really good"<< std::endl/*endline*/;
    /*std::cout : standered character output*/
    return 0;
    //if we reach return 0 there's no errors if one is returned there is
}