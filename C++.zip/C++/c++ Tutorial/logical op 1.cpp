#include <iostream>

int main(){
// && = both are true
// || = one if them is true 
// !  = reverse the function

int temp;
bool sunny = false;

//std::cout << "Enter the temp: ";
//std::cin >> temp ;

//if(temp > 0 && temp < 30){
//    std::cout << "The temp is good";
//}
//else{
//    std::cout << "the temp is bad";
//}

//if(temp <= 0 || temp >= 30){
//    std::cout << "The temp is bad";
//}
//else{
//    std::cout << "the temp is good";
//}

if(sunny){
    std::cout << "what a good day";
}
else{
    std::cout << "What a bad day";
}

    return 0 ;
}