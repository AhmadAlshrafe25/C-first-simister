#include <iostream>

int main(){
/*Suppose a and b are (int) variables, c is a
(double) variable, and a = 8, b = 45, and c = 3.5 . Evaluate the following
statements and show the results:*/
int a = 8;
int b = 45;
double c = 3.5;

std::cout<< a + b - c <<std::endl;//49.5
std::cout<< 14 / a + c <<std::endl;//4.5
std::cout<< b / a <<std::endl;//5
std::cout<< double(b)/a <<std::endl;//5.625
std::cout << a / double (b) + 2 * c <<std::endl;//7.17778
std::cout << 6 % 4 + 6.3 + b / a <<std::endl;//13.3
std::cout<< a + true + c + false <<std::endl;//12.5


    return 0;
}