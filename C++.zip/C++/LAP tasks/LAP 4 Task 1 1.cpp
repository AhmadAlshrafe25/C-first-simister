#include <iostream>

int main(){
/*Suppose that x, y, and z are int variables, and x = 7, 
y = 10, and z = 31. Determine whether the following expressions evaluate 
to true or false*/
int x = 7;
int y = 19;
int z = 31;

std::cout <<(x != 10) << std::endl;//true
std::cout << (( x + y ) > z) << std::endl;//false
std::cout << ((x + 24) == z) << std::endl;//true
std::cout << (x <= y)<<std::endl;//true

    return 0;
}