#include <iostream>

int main(){
/*Write C++ statements to do the following:
a. Declare int variables (Mark1, Mark2, and Mark3).
b. Initialize the Three variables (Mark1, Mark2, and Mark3).
c. Print the sum of three Marks.
d. Print the average of three Marks. (Note the result must have floating
point)*/
int M1 = 40 ;
int M2 = 30 ;
int M3 = 90 ;
int sum = M1 + M2 + M3;

std::cout << "YOUR sum is: "<<sum <<"\n";

double avg = (double)sum / 3;

std::cout << "YOUR avg is: "<<avg<<"\n";



    return 0;
}