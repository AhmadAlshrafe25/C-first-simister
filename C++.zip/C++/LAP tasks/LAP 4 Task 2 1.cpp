#include <iostream>

int main(){
/*Write C++ program that asks the user to enter two 
double Marks and print the statement "Grade = A" only if the sum of 
two Marks greater than 80*/
double M1 ;
double M2 ;

std::cout << "Enter First Mark : ";
std::cin  >> M1;

std::cout << "Enter Second Mark : ";
std::cin  >> M2;

double sum = M1 + M2 ;

if(sum > 80){
    std::cout << "Your grade is A";
}


    return 0;
}