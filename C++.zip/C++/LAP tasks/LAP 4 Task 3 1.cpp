#include <iostream>
#include <cmath>

int main(){
/*Takes two integers from the user (a base number and an 
exponent).
2) Calculates and print the power only if base number less than or 
equal to 10.*/

int base ;
int exp ;

std::cout << "Enter base number: ";
std::cin >> base;

std::cout << "Enter exponent number: ";
std::cin >> exp;

if(base <= 10){
   std::cout <<"YOUR result = "<< pow(base,exp);

}

    return 0;
}
