#include <iostream>

int main(){
/*a.Write a program that asks the user to enter an integer and prints whether the
number is even or odd
b. Extend the program to print whether the number is positive, negative, or zero
*/

int num ;

std::cout << "Enter NUM: ";
std::cin  >> num;

if(num % 2 == 0 && num < 0){
    std::cout << "The number is even and negative";
}
else if(num % 2 == 0 && num > 0){
    std::cout << "The number is even and Positive";
}
else if(num % 2 != 0 && num > 0){
    std::cout << "The number is odd and positive";
}
else if(num % 2 != 0 && num < 0){
    std::cout << "The number is odd and nigative";
}
else{
    std::cout << "The number is ZERO";
}

    return 0;
}